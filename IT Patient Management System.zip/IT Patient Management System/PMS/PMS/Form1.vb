﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Dim conn As New MySqlConnection
    Dim str As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConnectDatabase()
        Timer1.Enabled = True
        Label2.TextAlign = ContentAlignment.MiddleRight
        Label3.TextAlign = ContentAlignment.MiddleRight
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        ConnectDatabase()

    End Sub

    Public Sub ConnectDatabase()
        Dim DatabaseName As String = "pms"
        Dim server As String = "localhost"
        Dim userName As String = "root"
        Dim password As String = ""
        Dim ConvertZeroDT As String = "True"
        Dim AllowZeroDt As String = "True"
        If Not conn Is Nothing Then conn.Close()
        conn.ConnectionString = "server = " & server & "; user id = " & userName & ";" & "password = " & password & "; database = " & DatabaseName & "; Convert Zero Datetime = " & ConvertZeroDT & "; Allow Zero Datetime = " & AllowZeroDt & ""

        Try
            conn.Open()
            ' MsgBox("Connected")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            str = "SELECT * FROM tblpatientrecords"
            Dim da As New MySqlDataAdapter(str, conn)
            Dim dt As DataTable = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
        Me.Close()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Try
            str = "SELECT * FROM tblpatientrecords where Last_Name like '%" & TextBox1.Text & "%'"
            Dim da As New MySqlDataAdapter(str, conn)
            Dim dt As DataTable = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        With Form2
            .Text = DataGridView1.CurrentRow.Cells(0).Value
            .TextBox1.Text = DataGridView1.CurrentRow.Cells(1).Value
            .MaskedTextBox1.Text = DataGridView1.CurrentRow.Cells(2).Value
            .MaskedTextBox2.Text = DataGridView1.CurrentRow.Cells(3).Value
            .ComboBox1.Text = DataGridView1.CurrentRow.Cells(4).Value
            .DateTimePicker1.Text = DataGridView1.CurrentRow.Cells(5).Value
            .DateTimePicker2.Text = DataGridView1.CurrentRow.Cells(6).Value
            .Button2.Text = "Update Record"
            .Show()
            Me.Close()
        End With

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim cmd As New MySqlCommand
        Dim result As Integer
        Dim dgresult As New DialogResult
        dgresult = MessageBox.Show("Permanently delete record?", "Delete Patient Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If dgresult = Windows.Forms.DialogResult.Yes Then
            With cmd
                conn.Open()
                .Connection = conn
                .CommandText = "DELETE FROM `tblpatientrecords` WHERE `Patient_ID` = " & Val(DataGridView1.CurrentRow.Cells(0).Value) & ""
                result = .ExecuteNonQuery()
                If result > 0 Then
                    MsgBox("Record deleted successfully.")
                Else
                    MsgBox("Record deletion failed.")
                End If
            End With
        End If

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        MsgBox("Logged out successfully.")
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label3.Text = Date.Now.ToString("hh:mm:ss tt")
        Label2.Text = Date.Now.ToString("dd MMMM yyyy")
    End Sub
End Class

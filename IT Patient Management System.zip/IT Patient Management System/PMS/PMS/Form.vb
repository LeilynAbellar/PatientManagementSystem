﻿Imports MySql.Data.MySqlClient

Public Class Form
    Dim conn As New MySqlConnection
    Dim cmd As New MySqlCommand

    Private Sub Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If TextBox2.UseSystemPasswordChar = True Then

            TextBox2.UseSystemPasswordChar = False

        Else TextBox2.UseSystemPasswordChar = True

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Admin" And TextBox2.Text = "1234" Then
            MsgBox("Log in successful.")
            Form1.Show()
            Me.Close()
        Else
            MsgBox("Log in unsuccessful. Please check your UserID/Password.")
        End If
    End Sub

End Class
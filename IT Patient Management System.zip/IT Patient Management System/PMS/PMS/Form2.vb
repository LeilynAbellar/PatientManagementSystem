﻿Imports MySql.Data.MySqlClient

Public Class Form2
    Dim conn As New MySqlConnection

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConnectDatabase()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim cmd As New MySqlCommand
        Dim result As Integer

        Try
            With cmd
                If Button2.Text = "Save Record" Then

                    .Connection = conn
                    .CommandText = "INSERT INTO tblpatientrecords (Patient_ID, First_Name, Last_Name, Age, Sex, Admission, Discharge )" &
                " VALUES (NULL, '" & TextBox1.Text & "', '" & MaskedTextBox1.Text & "', '" & MaskedTextBox2.Text & "', '" & ComboBox1.Text & "','" & DateTimePicker1.Text & "', '" & DateTimePicker2.Text & "');"
                    result = .ExecuteNonQuery()
                    If result > 0 Then
                        MsgBox("New record added.")
                    Else
                        MsgBox("Adding new record failed.")
                    End If
                    Form1.Show()
                    Me.Close()
                Else
                    .Connection = conn
                    .CommandText = "UPDATE tblpatientrecords set First_Name = '" & TextBox1.Text & "', Last_Name = '" & MaskedTextBox1.Text & "', Age = '" & MaskedTextBox2.Text & "', Sex = '" & ComboBox1.Text & "', Admission = '" & DateTimePicker1.Text & "', Discharge = '" & DateTimePicker2.Text & "' WHERE Patient_ID = " & Val(Me.Text) & ""
                    result = .ExecuteNonQuery()
                    If result > 0 Then
                        MsgBox("Record updated successfully.")
                    Else
                        MsgBox("Record update failed.")
                    End If
                End If
                Form1.Show()
                Me.Close()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Public Sub ConnectDatabase()
        Dim DatabaseName As String = "pms"
        Dim server As String = "localhost"
        Dim userName As String = "root"
        Dim ConvertZeroDT As String = "true"
        Dim AllowZeroDt As String = "True"
        If Not conn Is Nothing Then conn.Close()
        conn.ConnectionString = "server = " & server & "; user id = " & userName & ";" & "password = " & password & "; database = " & DatabaseName & "; Convert Zero Datetime = " & ConvertZeroDT & "; Allow Zero Datetime = " & AllowZeroDt & ""

        Try
            conn.Open()
            ' MsgBox("Connected")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Close()
    End Sub
End Class
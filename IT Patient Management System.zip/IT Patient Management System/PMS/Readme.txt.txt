Notes:

User ID: Admin
Passworrd: 1234

* sytem cannot save data without turning on 
  connection for Apache and MySQL module

database link:
http://localhost/phpmyadmin/index.php?route=/table/structure/change&db=pms&table=tblpatientrecords&field=Admission&change_column=1

* if settings were reset, rright click "PMS" 
  and set startup form to "Form" at Appllication.

* to edit or delete, choose a record first before
  clicking the delete or update button.

* to see changes in the database, click the refresh
  button found at the top right of the form